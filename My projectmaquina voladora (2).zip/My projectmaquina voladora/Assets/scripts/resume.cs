using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class resume : MonoBehaviour
{
    public void Play()
    {
        Time.timeScale = 1f;

    }
}
