using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    public float moveSpeed;    
    public Rigidbody2D rb;
    private Vector2 moveDiretion;


   

    private void Update()
    {
        ProcessInput();
        //procesa los inputs
    }

    private void FixedUpdate()
    {
        Move();
        //calcula las fisicas
    }

     void ProcessInput()
    {
        float movex = Input.GetAxisRaw("Horizontal");
        float movey = Input.GetAxisRaw("Vertical");

        moveDiretion = new Vector2( movex, movey ); //TODO RETORNA ACA
    }

     void Move()
    {
        rb.velocity = new Vector2(moveDiretion.x * moveSpeed, moveDiretion.y * moveSpeed); //calcula la velocidad y direccion
    }

}
